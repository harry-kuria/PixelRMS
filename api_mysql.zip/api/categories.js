const express = require("express");
const bodyParser = require("body-parser");
const mysql = require("mysql");

const app = express();
const router = express.Router();
router.use(bodyParser.json());

// MySQL Connection Configuration
const connection = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "H@rri50nmysql",
  database: "POS_settings" // Assuming this database contains the settings
});

// Connect to MySQL
connection.connect((err) => {
  if (err) {
    console.error('Error connecting to MySQL: ' + err.stack);
    return;
  }
  console.log('Connected to MySQL as id ' + connection.threadId);
});

// Function to retrieve the database name from the settings table
function getDatabaseName(callback) {
  connection.query("SELECT JSON_UNQUOTE(JSON_EXTRACT(settings, '$.store')) AS store FROM settings WHERE _id = 1;", (err, result) => {
    if (err) {
      console.error("Error executing SQL query:", err.sqlMessage);
      return callback(err, null);
    }
    if (result.length === 0) {
      const errMsg = "No rows found in settings table with id = 1";
      console.error(errMsg);
      return callback(new Error(errMsg), null);
    }
    const dbName = result[0].store;
    callback(null, dbName);
  });
}

// Routes
router.get("/", (req, res) => {
  res.send("Category API");
});

// Get all categories
router.get("/all", (req, res) => {
  getDatabaseName((err, dbName) => {
    if (err) {
      return res.status(500).send(err.message);
    }
    const connectionWithDb = mysql.createConnection({
      host: "localhost",
      user: "root",
      password: "H@rri50nmysql",
      database: dbName
    });

    connectionWithDb.query("SELECT * FROM categories", (err, result) => {
      if (err) {
        console.error("Error getting categories:", err);
        return res.status(500).send(err.message);
      }
      res.send(result);
    });
  });
});

// Create a new category
router.post("/category", (req, res) => {
  getDatabaseName((err, dbName) => {
    if (err) {
      return res.status(500).send(err.message);
    }
    const connectionWithDb = mysql.createConnection({
      host: "localhost",
      user: "root",
      password: "H@rri50nmysql",
      database: dbName
    });

    const newCategory = req.body;
    newCategory.id = Math.floor(Date.now() / 1000); // Generate unique ID
    connectionWithDb.query("INSERT INTO categories SET ?", newCategory, (err, result) => {
      if (err) {
        console.error("Error creating category:", err);
        return res.status(500).send(err.message);
      }
      res.sendStatus(200);
    });
  });
});

// Delete a category by ID
router.delete("/category/:categoryId", (req, res) => {
  getDatabaseName((err, dbName) => {
    if (err) {
      return res.status(500).send(err.message);
    }
    const connectionWithDb = mysql.createConnection({
      host: "localhost",
      user: "root",
      password: "H@rri50nmysql",
      database: dbName
    });

    const categoryId = req.params.categoryId;
    connectionWithDb.query("DELETE FROM categories WHERE id = ?", categoryId, (err, result) => {
      if (err) {
        console.error("Error deleting category:", err);
        return res.status(500).send(err.message);
      }
      res.sendStatus(200);
    });
  });
});

// Update a category
router.put("/category", (req, res) => {
  getDatabaseName((err, dbName) => {
    if (err) {
      return res.status(500).send(err.message);
    }
    const connectionWithDb = mysql.createConnection({
      host: "localhost",
      user: "root",
      password: "H@rri50nmysql",
      database: dbName
    });

    const categoryId = req.body.id;
    connectionWithDb.query("UPDATE categories SET ? WHERE id = ?", [req.body, categoryId], (err, result) => {
      if (err) {
        console.error("Error updating category:", err);
        return res.status(500).send(err.message);
      }
      res.sendStatus(200);
    });
  });
});

// Start the server
module.exports = router; 

// const router = require( "express" )();
// const server = require( "http" ).Server( router );
// const bodyParser = require( "body-parser" );
// const Datastore = require( "nedb" );
// const async = require( "async" );


// router.use( bodyParser.json() );

// module.exports = router;

 
// let categoryDB = new Datastore( {
//     filename: process.env.routerDATA+"/POS/server/databases/categories.db",
//     autoload: true
// } );


// categoryDB.ensureIndex({ fieldName: 'id', unique: true });
// router.get( "/", function ( req, res ) {
//     res.send( "Category API" );
// } );


  
// router.get( "/all", function ( req, res ) {
//     categoryDB.find( {}, function ( err, docs ) {
//         res.send( docs );
//     } );
// } );

 
// router.post( "/category", function ( req, res ) {
//     let newCategory = req.body;
//     newCategory.id = Math.floor(Date.now() / 1000); 
//     categoryDB.insert( newCategory, function ( err, category) {
//         if ( err ) res.status( 500 ).send( err );
//         else res.sendStatus( 200 );
//     } );
// } );



// router.delete( "/category/:categoryId", function ( req, res ) {
//     categoryDB.remove( {
//         id: parseInt(req.params.categoryId)
//     }, function ( err, numRemoved ) {
//         if ( err ) res.status( 500 ).send( err );
//         else res.sendStatus( 200 );
//     } );
// } );

 

 
// router.put( "/category", function ( req, res ) {
//     categoryDB.update( {
//         id: parseInt(req.body.id)
//     }, req.body, {}, function (
//         err,
//         numReplaced,
//         category
//     ) {
//         if ( err ) res.status( 500 ).send( err );
//         else res.sendStatus( 200 );
//     } );
// });



 