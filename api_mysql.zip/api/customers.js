const express = require("express");
const bodyParser = require("body-parser");
const mysql = require("mysql");

const app = express.Router();
app.use(bodyParser.json());

// MySQL Connection Configuration
const connection = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "H@rri50nmysql",
  database: "POS_settings"
});

// Connect to MySQL
connection.connect((err) => {
  if (err) {
    console.error('Error connecting to MySQL: ' + err.stack);
    return;
  }
  console.log('Connected to MySQL as id ' + connection.threadId);
});

function getDatabaseName(callback) {
  connection.query("SELECT JSON_UNQUOTE(JSON_EXTRACT(settings, '$.store')) AS store FROM settings WHERE _id = 1;", (err, result) => {
    if (err) {
      console.error("Error executing SQL query:", err.sqlMessage);
      return callback(err, null);
    }
    if (result.length === 0) {
      const errMsg = "No rows found in settings table with id = 1";
      console.error(errMsg);
      return callback(new Error(errMsg), null);
    }
    const dbName = result[0].store;
    callback(null, dbName);
  });
}

// Routes
app.get("/", (req, res) => {
  res.send("Customer API");
});

// Get customer by ID
app.get("/customer/:customerId", (req, res) => {
  const customerId = req.params.customerId;
  getDatabaseName((err, dbName) => {
    if (err) {
      return res.status(500).send(err.message);
    }
    const connectionWithDb = mysql.createConnection({
      host: "localhost",
      user: "root",
      password: "H@rri50nmysql",
      database: dbName
    });

    connectionWithDb.query("SELECT * FROM customers WHERE _id = ?", customerId, (err, result) => {
    if (err) {
      console.error("Error getting customer:", err);
      return res.status(500).send(err.message);
    }
    res.send(result[0]);
  });
});
});

// Get all customers
app.get("/all", (req, res) => {
  getDatabaseName((err, dbName) => {
    if (err) {
      return res.status(500).send(err.message);
    }
    const connectionWithDb = mysql.createConnection({
      host: "localhost",
      user: "root",
      password: "H@rri50nmysql",
      database: dbName
    });

    connectionWithDb.query("SELECT * FROM customers", (err, result) => {
    if (err) {
      console.error("Error getting customers:", err);
      return res.status(500).send(err.message);
    }
    res.send(result);
  });
})
});

// Create a new customer
app.post("/customer", (req, res) => {
  const newCustomer = req.body;
  getDatabaseName((err, dbName) => {
    if (err) {
      return res.status(500).send(err.message);
    }
    const connectionWithDb = mysql.createConnection({
      host: "localhost",
      user: "root",
      password: "H@rri50nmysql",
      database: dbName
    });

    connectionWithDb.query("INSERT INTO customers SET ?", newCustomer, (err, result) => {
    if (err) {
      console.error("Error creating customer:", err);
      return res.status(500).send(err.message);
    }
    res.sendStatus(200);
  });
})
});

// Delete a customer by ID
app.delete("/customer/:customerId", (req, res) => {
  const customerId = req.params.customerId;
  getDatabaseName((err, dbName) => {
    if (err) {
      return res.status(500).send(err.message);
    }
    const connectionWithDb = mysql.createConnection({
      host: "localhost",
      user: "root",
      password: "H@rri50nmysql",
      database: dbName
    });

    connectionWithDb.query("DELETE FROM customers WHERE _id = ?", customerId, (err, result) => {
    if (err) {
      console.error("Error deleting customer:", err);
      return res.status(500).send(err.message);
    }
    res.sendStatus(200);
  });
})
});

// Update a customer
app.put("/customer", (req, res) => {
  const customerId = req.body._id;
  getDatabaseName((err, dbName) => {
    if (err) {
      return res.status(500).send(err.message);
    }
    const connectionWithDb = mysql.createConnection({
      host: "localhost",
      user: "root",
      password: "H@rri50nmysql",
      database: dbName
    });

    connectionWithDb.query("UPDATE customers SET ? WHERE _id = ?", [req.body, customerId], (err, result) => {
    if (err) {
      console.error("Error updating customer:", err);
      return res.status(500).send(err.message);
    }
    res.sendStatus(200);
  });
})
});

// Start the server
module.exports = app;


// const app = require( "express" )();
// const server = require( "http" ).Server( app );
// const bodyParser = require( "body-parser" );
// const Datastore = require( "nedb" );
// const async = require( "async" );

// app.use( bodyParser.json() );

// module.exports = app;

 
// let customerDB = new Datastore( {
//     filename: process.env.APPDATA+"/POS/server/databases/customers.db",
//     autoload: true
// } );


// customerDB.ensureIndex({ fieldName: '_id', unique: true });


// app.get( "/", function ( req, res ) {
//     res.send( "Customer API" );
// } );


// app.get( "/customer/:customerId", function ( req, res ) {
//     if ( !req.params.customerId ) {
//         res.status( 500 ).send( "ID field is required." );
//     } else {
//         customerDB.findOne( {
//             _id: req.params.customerId
//         }, function ( err, customer ) {
//             res.send( customer );
//         } );
//     }
// } );

 
// app.get( "/all", function ( req, res ) {
//     customerDB.find( {}, function ( err, docs ) {
//         res.send( docs );
//     } );
// } );

 
// app.post( "/customer", function ( req, res ) {
//     var newCustomer = req.body;
//     customerDB.insert( newCustomer, function ( err, customer ) {
//         if ( err ) res.status( 500 ).send( err );
//         else res.sendStatus( 200 );
//     } );
// } );



// app.delete( "/customer/:customerId", function ( req, res ) {
//     customerDB.remove( {
//         _id: req.params.customerId
//     }, function ( err, numRemoved ) {
//         if ( err ) res.status( 500 ).send( err );
//         else res.sendStatus( 200 );
//     } );
// } );

 

 
// app.put( "/customer", function ( req, res ) {
//     let customerId = req.body._id;

//     customerDB.update( {
//         _id: customerId
//     }, req.body, {}, function (
//         err,
//         numReplaced,
//         customer
//     ) {
//         if ( err ) res.status( 500 ).send( err );
//         else res.sendStatus( 200 );
//     } );
// });



 