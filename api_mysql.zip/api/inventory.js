const express = require("express");
const bodyParser = require("body-parser");
const multer = require("multer");
const fs = require('fs');
const mysql = require("mysql");

const app = express.Router();
app.use(bodyParser.json());

// MySQL Connection Configuration
const connection = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "H@rri50nmysql",
  database: "POS_settings"
});

// Connect to MySQL
connection.connect((err) => {
  if (err) {
    console.error('Error connecting to MySQL: ' + err.stack);
    return;
  }
  console.log('Connected to MySQL as id ' + connection.threadId);
});


// Multer storage configuration
const storage = multer.diskStorage({
  destination: process.env.APPDATA+'/POS/uploads',
  filename: function(req, file, callback){
    callback(null, Date.now() + '.jpg'); // Save file with current timestamp as filename
  }
});
const upload = multer({storage: storage});
function getDatabaseName(callback) {
  connection.query("SELECT JSON_UNQUOTE(JSON_EXTRACT(settings, '$.store')) AS store FROM settings WHERE _id = 1;", (err, result) => {
    if (err) {
      console.error("Error executing SQL query:", err.sqlMessage);
      return callback(err, null);
    }
    if (result.length === 0) {
      const errMsg = "No rows found in settings table with id = 1";
      console.error(errMsg);
      return callback(new Error(errMsg), null);
    }
    const dbName = result[0].store;
    callback(null, dbName);
  });
}
// Routes
app.get("/", (req, res) => {
  res.send("Inventory API");
});

// Get product by ID
app.get("/product/:productId", (req, res) => {
  const productId = req.params.productId;
  getDatabaseName((err, dbName) => {
    if (err) {
      return res.status(500).send(err.message);
    }
    const connectionWithDb = mysql.createConnection({
      host: "localhost",
      user: "root",
      password: "H@rri50nmysql",
      database: dbName
    });

    connectionWithDb.query("SELECT * FROM inventory WHERE _id = ?", productId, (err, result) => {
    if (err) {
      console.error("Error getting product:", err);
      return res.status(500).send(err.message);
    }
    res.send(result[0]);
  });
});
});

// Get all products
app.get("/products", (req, res) => {
  getDatabaseName((err, dbName) => {
    if (err) {
      return res.status(500).send(err.message);
    }
    const connectionWithDb = mysql.createConnection({
      host: "localhost",
      user: "root",
      password: "H@rri50nmysql",
      database: dbName
    });

    connectionWithDb.query("SELECT * FROM inventory", (err, result) => {
    if (err) {
      console.error("Error getting products:", err);
      return res.status(500).send(err.message);
    }
    res.send(result);
  });
});
});

// Create or update a product and handle file upload
app.post("/product", upload.single('imagename'), (req, res) => {
  let image = '';

  if (req.body.img !== "") {
    image = req.body.img;
  }

  if (req.file) {
    image = req.file.filename;
  }

  if (req.body.remove == 1) {
    const path = process.env.APPDATA+"/POS/uploads/"+ req.body.img;
    try {
      fs.unlinkSync(path)
    } catch(err) {
      console.error(err)
    }

    if (!req.file) {
      image = '';
    }
  }

  const product = {
    _id: parseInt(req.body.id),
    price: req.body.price,
    category: req.body.category,
    quantity: req.body.quantity === "" ? 0 : req.body.quantity,
    name: req.body.name,
    stock: req.body.stock === "on" ? 0 : 1,
    img: image
  };

  if (req.body.id === "") { 
    product._id = Math.floor(Date.now() / 1000);
    getDatabaseName((err, dbName) => {
      if (err) {
        return res.status(500).send(err.message);
      }
      const connectionWithDb = mysql.createConnection({
        host: "localhost",
        user: "root",
        password: "H@rri50nmysql",
        database: dbName
      });
  
      connectionWithDb.query("INSERT INTO inventory SET ?", product, (err, result) => {
      if (err) {
        console.error("Error creating product:", err);
        return res.status(500).send(err.message);
      }
      res.send(product);
    });
  });
  } else { 
    getDatabaseName((err, dbName) => {
      if (err) {
        return res.status(500).send(err.message);
      }
      const connectionWithDb = mysql.createConnection({
        host: "localhost",
        user: "root",
        password: "H@rri50nmysql",
        database: dbName
      });
  
      connectionWithDb.query("UPDATE inventory SET ? WHERE _id = ?", [product, product._id], (err, result) => {
      if (err) {
        console.error("Error updating product:", err);
        return res.status(500).send(err.message);
      }
      res.sendStatus(200);
    });
  });
  }
});

// Delete a product by ID
app.delete("/product/:productId", (req, res) => {
  const productId = req.params.productId;
  getDatabaseName((err, dbName) => {
    if (err) {
      return res.status(500).send(err.message);
    }
    const connectionWithDb = mysql.createConnection({
      host: "localhost",
      user: "root",
      password: "H@rri50nmysql",
      database: dbName
    });

    connectionWithDb.query("DELETE FROM inventory WHERE _id = ?", productId, (err, result) => {
    if (err) {
      console.error("Error deleting product:", err);
      return res.status(500).send(err.message);
    }
    res.sendStatus(200);
  });
});
});

// Find product by SKU
app.post("/product/sku", (req, res) => {
  const skuCode = req.body.skuCode;
  getDatabaseName((err, dbName) => {
    if (err) {
      return res.status(500).send(err.message);
    }
    const connectionWithDb = mysql.createConnection({
      host: "localhost",
      user: "root",
      password: "H@rri50nmysql",
      database: dbName
    });

    connectionWithDb.query("SELECT * FROM inventory WHERE _id = ?", skuCode, (err, result) => {
    if (err) {
      console.error("Error finding product by SKU:", err);
      return res.status(500).send(err.message);
    }
    res.send(result[0]);
  });
});
});

// Decrement inventory
app.decrementInventory = (products) => {
  async.eachSeries(products, (transactionProduct, callback) => {
    const productId = parseInt(transactionProduct.id);
    getDatabaseName((err, dbName) => {
      if (err) {
        return res.status(500).send(err.message);
      }
      const connectionWithDb = mysql.createConnection({
        host: "localhost",
        user: "root",
        password: "H@rri50nmysql",
        database: dbName
      });
  
      connectionWithDb.query("SELECT * FROM inventory WHERE _id = ?", productId, (err, product) => {
      if (err || !product || !product.quantity) {
        return callback();
      }
    });
      const updatedQuantity = parseInt(product.quantity) - parseInt(transactionProduct.quantity);
      getDatabaseName((err, dbName) => {
        if (err) {
          return res.status(500).send(err.message);
        }
        const connectionWithDb = mysql.createConnection({
          host: "localhost",
          user: "root",
          password: "H@rri50nmysql",
          database: dbName
        });
    
        connectionWithDb.query("UPDATE inventory SET quantity = ? WHERE _id = ?", [updatedQuantity, productId], callback);
      });
      });

  });
};

module.exports = app; 



// const app = require( "express" )();
// const server = require( "http" ).Server( app );
// const bodyParser = require( "body-parser" );
// const Datastore = require( "nedb" );
// const async = require( "async" );
// const fileUpload = require('express-fileupload');
// const multer = require("multer");
// const fs = require('fs');


// const storage = multer.diskStorage({
//     destination: process.env.APPDATA+'/POS/uploads',
//     filename: function(req, file, callback){
//         callback(null, Date.now() + '.jpg'); // 
//     }
// });


// let upload = multer({storage: storage});

// app.use(bodyParser.json());


// module.exports = app;

 
// let inventoryDB = new Datastore( {
//     filename: process.env.APPDATA+"/POS/server/databases/inventory.db",
//     autoload: true
// } );


// inventoryDB.ensureIndex({ fieldName: '_id', unique: true });

 
// app.get( "/", function ( req, res ) {
//     res.send( "Inventory API" );
// } );


 
// app.get( "/product/:productId", function ( req, res ) {
//     if ( !req.params.productId ) {
//         res.status( 500 ).send( "ID field is required." );
//     } else {
//         inventoryDB.findOne( {
//             _id: parseInt(req.params.productId)
//         }, function ( err, product ) {
//             res.send( product );
//         } );
//     }
// } );


 
// app.get( "/products", function ( req, res ) {
//     inventoryDB.find( {}, function ( err, docs ) {
//         res.send( docs );
//     } );
// } );


 
// app.post( "/product", upload.single('imagename'), function ( req, res ) {

//     let image = '';

//     if(req.body.img != "") {
//         image = req.body.img;        
//     }

//     if(req.file) {
//         image = req.file.filename;  
//     }
 

//     if(req.body.remove == 1) {
//         const path = './resources/app/public/uploads/product_image/'+ req.body.img;
//         try {
//           fs.unlinkSync(path)
//         } catch(err) {
//           console.error(err)
//         }

//         if(!req.file) {
//             image = '';
//         }
//     }
    
//     let Product = {
//         _id: parseInt(req.body.id),
//         price: req.body.price,
//         category: req.body.category,
//         quantity: req.body.quantity == "" ? 0 : req.body.quantity,
//         name: req.body.name,
//         stock: req.body.stock == "on" ? 0 : 1,    
//         img: image        
//     }

//     if(req.body.id == "") { 
//         Product._id = Math.floor(Date.now() / 1000);
//         inventoryDB.insert( Product, function ( err, product ) {
//             if ( err ) res.status( 500 ).send( err );
//             else res.send( product );
//         });
//     }
//     else { 
//         inventoryDB.update( {
//             _id: parseInt(req.body.id)
//         }, Product, {}, function (
//             err,
//             numReplaced,
//             product
//         ) {
//             if ( err ) res.status( 500 ).send( err );
//             else res.sendStatus( 200 );
//         } );

//     }

// });



 
// app.delete( "/product/:productId", function ( req, res ) {
//     inventoryDB.remove( {
//         _id: parseInt(req.params.productId)
//     }, function ( err, numRemoved ) {
//         if ( err ) res.status( 500 ).send( err );
//         else res.sendStatus( 200 );
//     } );
// } );

 

// app.post( "/product/sku", function ( req, res ) {
//     var request = req.body;
//     inventoryDB.findOne( {
//             _id: parseInt(request.skuCode)
//     }, function ( err, product ) {
//          res.send( product );
//     } );
// } );

 


// app.decrementInventory = function ( products ) {

//     async.eachSeries( products, function ( transactionProduct, callback ) {
//         inventoryDB.findOne( {
//             _id: parseInt(transactionProduct.id)
//         }, function (
//             err,
//             product
//         ) {
    
//             if ( !product || !product.quantity ) {
//                 callback();
//             } else {
//                 let updatedQuantity =
//                     parseInt( product.quantity) -
//                     parseInt( transactionProduct.quantity );

//                 inventoryDB.update( {
//                         _id: parseInt(product._id)
//                     }, {
//                         $set: {
//                             quantity: updatedQuantity
//                         }
//                     }, {},
//                     callback
//                 );
//             }
//         } );
//     } );
// };