const express = require("express");
const bodyParser = require("body-parser");
const multer = require("multer");
const fs = require('fs');
const mysql = require("mysql");

const router = express.Router(); // Create an Express router

// MySQL Connection Configuration
const connection = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "H@rri50nmysql",
  database: "POS_settings"
});

// Connect to MySQL
connection.connect((err) => {
  if (err) {
    console.error('Error connecting to MySQL: ' + err.stack);
    return;
  }
  console.log('Connected to MySQL as id ' + connection.threadId);

  // Create the 'settings' table if it doesn't exist
  connection.query(`CREATE TABLE IF NOT EXISTS settings (
    _id INT AUTO_INCREMENT PRIMARY KEY,
    settings JSON
);`, (err) => {
    if (err) {
      console.error("Error creating settings table:", err);
      return;
    }
    console.log("Settings table created successfully");
  });
});


// Multer storage configuration
const storage = multer.diskStorage({
  destination: process.env.APPDATA+'/POS/uploads',
  filename: function(req, file, callback){
    callback(null, Date.now() + '.jpg'); // Save file with current timestamp as filename
  }
});
const upload = multer({storage: storage});

// Get settings
router.get("/get", (req, res) => {
  connection.query("SELECT * FROM settings WHERE _id = 1", (err, result) => {
    if (err) {
      console.error("Error getting settings:", err);
      return res.status(500).send(err.message);
    }
    res.send(result[0]);
  });
});

// Post settings and handle file upload
// Post settings and handle file upload
router.post("/post", upload.single('imagename'), (req, res) => {
  let image = '';

  if (req.body.img !== "") {
    image = req.body.img;
  }

  if (req.file) {
    image = req.file.filename;
  }

  if (req.body.remove == 1) {
    const path = process.env.APPDATA+"/POS/uploads/"+ req.body.img;
    try {
      fs.unlinkSync(path)
    } catch(err) {
      console.error(err)
    }

    if (!req.file) {
      image = '';
    }
  } 

  const settings = {
    app: req.body.app,
    store: req.body.store,
    address_one: req.body.address_one,
    address_two: req.body.address_two,
    contact: req.body.contact,
    tax: req.body.tax,
    symbol: req.body.symbol,
    percentage: req.body.percentage,
    charge_tax: req.body.charge_tax,
    footer: req.body.footer,
    img: image
  };

  // Insert settings into the 'settings' table
  connection.query("INSERT INTO settings (_id, settings) VALUES (1, ?) ON DUPLICATE KEY UPDATE settings = ?", [JSON.stringify(settings), JSON.stringify(settings)], (err, result) => {
    if (err) {
      console.error("Error saving settings:", err);
      return res.status(500).send(err.message);
    }

    // Create a new database based on the 'store' value from the settings
    connection.query("CREATE DATABASE IF NOT EXISTS ??", [req.body.store], (err) => {
      if (err) {
        console.error("Error creating database:", err);
        return res.status(500).send(err.message);
      }

      // After creating the database, switch to the newly created database
      connection.changeUser({ database: req.body.store }, (err) => {
        if (err) {
          console.error("Error switching to database:", err);
          return res.status(500).send(err.message);
        }
    
        // Create additional tables
        const createTablesQueries = [
          "CREATE TABLE IF NOT EXISTS categories (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(255) NOT NULL)",
          "CREATE TABLE IF NOT EXISTS customers (_id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(255) NOT NULL, phone VARCHAR(20), email VARCHAR(255), kra_pin VARCHAR(20))",
          "CREATE TABLE IF NOT EXISTS inventory (_id INT AUTO_INCREMENT PRIMARY KEY, price DECIMAL(10,2) NOT NULL, category VARCHAR(255) NOT NULL, quantity INT NOT NULL, name VARCHAR(255) NOT NULL, stock INT NOT NULL, img VARCHAR(255))",
          "CREATE TABLE IF NOT EXISTS settings (_id INT AUTO_INCREMENT PRIMARY KEY, settings JSON)",
          "CREATE TABLE IF NOT EXISTS transactions (id INT AUTO_INCREMENT PRIMARY KEY, data TEXT)",
          "CREATE TABLE IF NOT EXISTS users (id INT AUTO_INCREMENT PRIMARY KEY, username VARCHAR(255) NOT NULL, password VARCHAR(255) NOT NULL, fullname VARCHAR(255) NOT NULL, perm_products TINYINT(1) DEFAULT 0, perm_categories TINYINT(1) DEFAULT 0, perm_transactions TINYINT(1) DEFAULT 0, perm_users TINYINT(1) DEFAULT 0, perm_settings TINYINT(1) DEFAULT 0, status VARCHAR(255))"
        ];
    
        // Execute each query in the array separately
        createTablesQueries.forEach(query => {
          connection.query(query, (err) => {
            if (err) {
              console.error("Error creating tables:", err);
              return res.status(500).send(err.message);
            }
          });
        });
        const settingsQuery = "INSERT INTO settings (_id, settings) VALUES (1, ?) ON DUPLICATE KEY UPDATE settings = ?";
        connection.query(settingsQuery, [JSON.stringify(settings), JSON.stringify(settings)], (err) => {
          if (err) {
            console.error("Error inserting settings:", err);
            return res.status(500).send(err.message);
          }

          // Send response after all queries have been executed
          res.sendStatus(200);
        });
        });
      });
    });
  });
module.exports = router; // Export the router middleware


// const app = require( "express")();
// const server = require( "http" ).Server( app );
// const bodyParser = require( "body-parser" );
// const Datastore = require( "nedb" );
// const multer = require("multer");
// const fileUpload = require('express-fileupload');
// const fs = require('fs');


// const storage = multer.diskStorage({
//     destination:  process.env.APPDATA+'/POS/uploads',
//     filename: function(req, file, callback){
//         callback(null, Date.now() + '.jpg'); // 
//     }
// });

// let upload = multer({storage: storage});

// app.use( bodyParser.json() );

// module.exports = app;

 
// let settingsDB = new Datastore( {
//     filename: process.env.APPDATA+"/POS/server/databases/settings.db",
//     autoload: true
// } );



// app.get( "/", function ( req, res ) {
//     res.send( "Settings API" );
// } );


  
// app.get( "/get", function ( req, res ) {
//     settingsDB.findOne( {
//         _id: 1
// }, function ( err, docs ) {
//         res.send( docs );
//     } );
// } );

 
// app.post( "/post", upload.single('imagename'), function ( req, res ) {

//     let image = '';

//     if(req.body.img != "") {
//         image = req.body.img;       
//     }

//     if(req.file) {
//         image = req.file.filename;  
//     }

//     if(req.body.remove == 1) {
//         const path = process.env.APPDATA+"/POS/uploads/"+ req.body.img;
//         try {
//           fs.unlinkSync(path)
//         } catch(err) {
//           console.error(err)
//         }

//         if(!req.file) {
//             image = '';
//         }
//     } 
    
  
//     let Settings = {  
//         _id: 1,
//         settings: {
//             "app": req.body.app,
//             "store": req.body.store,
//             "address_one": req.body.address_one,
//             "address_two":req.body.address_two,
//             "contact": req.body.contact,
//             "tax": req.body.tax,
//             "symbol": req.body.symbol,
//             "percentage": req.body.percentage,
//             "charge_tax": req.body.charge_tax,
//             "footer": req.body.footer,
//             "img": image
//         }       
//     }

//     if(req.body.id == "") { 
//         settingsDB.insert( Settings, function ( err, settings ) {
//             if ( err ) res.status( 500 ).send( err );
//             else res.send( settings );
//         });
//     }
//     else { 
//         settingsDB.update( {
//             _id: 1
//         }, Settings, {}, function (
//             err,
//             numReplaced,
//             settings
//         ) {
//             if ( err ) res.status( 500 ).send( err );
//             else res.sendStatus( 200 );
//         } );

//     }

// });

 