const express = require("express");
const bodyParser = require("body-parser");
const mysql = require("mysql");

const app = express.Router();
app.use(bodyParser.json());

// MySQL Connection Configuration
const connection = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "H@rri50nmysql",
  database: "POS_settings"
});

// Connect to MySQL
connection.connect((err) => {
  if (err) {
    console.error('Error connecting to MySQL: ' + err.stack);
    return;
  }
  console.log('Connected to MySQL as id ' + connection.threadId);
});

function getDatabaseName(callback) {
  connection.query("SELECT JSON_UNQUOTE(JSON_EXTRACT(settings, '$.store')) AS store FROM settings WHERE _id = 1;", (err, result) => {
    if (err) {
      console.error("Error executing SQL query:", err.sqlMessage);
      return callback(err, null);
    }
    if (result.length === 0) {
      const errMsg = "No rows found in settings table with id = 1";
      console.error(errMsg);
      return callback(new Error(errMsg), null);
    }
    const dbName = result[0].store;
    callback(null, dbName);
  });
}

// Routes
app.get("/", (req, res) => {
  res.send("Transactions API");
});

// Get all transactions
app.get("/all", (req, res) => {
  getDatabaseName((err, dbName) => {
    if (err) {
      return res.status(500).send(err.message);
    }
    const connectionWithDb = mysql.createConnection({
      host: "localhost",
      user: "root",
      password: "H@rri50nmysql",
      database: dbName
    });

    connectionWithDb.query("SELECT * FROM transactions", (err, results) => {
    if (err) {
      console.error("Error getting transactions:", err);
      return res.status(500).send(err.message);
    }
    res.send(results);
  });
});
});

// Get transactions on hold
app.get("/on-hold", (req, res) => {
  getDatabaseName((err, dbName) => {
    if (err) {
      return res.status(500).send(err.message);
    }
    const connectionWithDb = mysql.createConnection({
      host: "localhost",
      user: "root",
      password: "H@rri50nmysql",
      database: dbName
    });

    connectionWithDb.query(
    "SELECT * FROM transactions WHERE ref_number != '' AND status = 0",
    (err, results) => {
      if (err) {
        console.error("Error getting transactions on hold:", err);
        return res.status(500).send(err.message);
      }
      res.send(results);
    }
  );
  })
});

// Get customer orders
app.get("/customer-orders", (req, res) => {
  getDatabaseName((err, dbName) => {
    if (err) {
      return res.status(500).send(err.message);
    }
    const connectionWithDb = mysql.createConnection({
      host: "localhost",
      user: "root",
      password: "H@rri50nmysql",
      database: dbName
    });

    connectionWithDb.query(
    "SELECT * FROM transactions WHERE customer != '0' AND status = 0 AND ref_number = ''",
    (err, results) => {
      if (err) {
        console.error("Error getting customer orders:", err);
        return res.status(500).send(err.message);
      }
      res.send(results);
    }
  );
  });
});

// Get transactions by date
app.get("/by-date", (req, res) => {
  const startDate = req.query.start;
  const endDate = req.query.end;
  const user = req.query.user || 0;
  const till = req.query.till || 0;
  const status = req.query.status || 0;

  let query = "SELECT * FROM transactions WHERE date BETWEEN ? AND ?";

  const queryParams = [startDate, endDate];

  if (user !== 0) {
    query += " AND user_id = ?";
    queryParams.push(user);
  }

  if (till !== 0) {
    query += " AND till = ?";
    queryParams.push(till);
  }

  if (status !== 0) {
    query += " AND status = ?";
    queryParams.push(status);
  }
  getDatabaseName((err, dbName) => {
    if (err) {
      return res.status(500).send(err.message);
    }
    const connectionWithDb = mysql.createConnection({
      host: "localhost",
      user: "root",
      password: "H@rri50nmysql",
      database: dbName
    });

    connectionWithDb.query(query, queryParams, (err, results) => {
    if (err) {
      console.error("Error getting transactions by date:", err);
      return res.status(500).send(err.message);
    }
    res.send(results);
  });
});
});

// Create a new transaction
app.post("/new", (req, res) => {
  const newTransaction = req.body;
  console.log(req.body)
  getDatabaseName((err, dbName) => {
    if (err) {
      return res.status(500).send(err.message);
    }
    const connectionWithDb = mysql.createConnection({
      host: "localhost",
      user: "root",
      password: "H@rri50nmysql",
      database: dbName
    });

    // Convert the date format to match MySQL's expected format
    newTransaction.date = new Date(newTransaction.date).toISOString().slice(0, 19).replace('T', ' ');

    // Stringify the 'items' array before inserting into the database
    newTransaction.items = JSON.stringify(newTransaction.items);

    connectionWithDb.query(
      "INSERT INTO transactions SET ?",
      newTransaction,
      (err, result) => {
        if (err) {
          console.error("Error creating transaction:", err);
          return res.status(500).send(err.message);
        }
        res.sendStatus(200);
      }
    );
  });
});


// Update a transaction
app.put("/new", (req, res) => {
  const orderId = req.body._id;
  getDatabaseName((err, dbName) => {
    if (err) {
      return res.status(500).send(err.message);
    }
    const connectionWithDb = mysql.createConnection({
      host: "localhost",
      user: "root",
      password: "H@rri50nmysql",
      database: dbName
    });

    connectionWithDb.query(
    "UPDATE transactions SET ? WHERE _id = ?",
    [req.body, orderId],
    (err, result) => {
      if (err) {
        console.error("Error updating transaction:", err);
        return res.status(500).send(err.message);
      }
      res.sendStatus(200);
    }
  );
  })
});

// Delete a transaction
app.post("/delete", (req, res) => {
  const transactionId = req.body.orderId;
  getDatabaseName((err, dbName) => {
    if (err) {
      return res.status(500).send(err.message);
    }
    const connectionWithDb = mysql.createConnection({
      host: "localhost",
      user: "root",
      password: "H@rri50nmysql",
      database: dbName
    });

    connectionWithDb.query(
    "DELETE FROM transactions WHERE _id = ?",
    transactionId,
    (err, result) => {
      if (err) {
        console.error("Error deleting transaction:", err);
        return res.status(500).send(err.message);
      }
      res.sendStatus(200);
    }
  );
  });
});

// Get transaction by ID
app.get("/:transactionId", (req, res) => {
  getDatabaseName((err, dbName) => {
    if (err) {
      return res.status(500).send(err.message);
    }
    const connectionWithDb = mysql.createConnection({
      host: "localhost",
      user: "root",
      password: "H@rri50nmysql",
      database: dbName
    });

    connectionWithDb.query(
    "SELECT * FROM transactions WHERE _id = ?",
    req.params.transactionId,
    (err, result) => {
      if (err) {
        console.error("Error getting transaction by ID:", err);
        return res.status(500).send(err.message);
      }
      res.send(result);
    }
  );
  })
});

// Start the server
module.exports = app;

// let app = require("express")();
// let server = require("http").Server(app);
// let bodyParser = require("body-parser");
// let Datastore = require("nedb");
// let Inventory = require("./inventory");

// app.use(bodyParser.json());

// module.exports = app;
 
// let transactionsDB = new Datastore({
//   filename: process.env.APPDATA+"/POS/server/databases/transactions.db",
//   autoload: true
// });


// transactionsDB.ensureIndex({ fieldName: '_id', unique: true });

// app.get("/", function(req, res) {
//   res.send("Transactions API");
// });

 
// app.get("/all", function(req, res) {
//   transactionsDB.find({}, function(err, docs) {
//     res.send(docs);
//   });
// });



 
// app.get("/on-hold", function(req, res) {
//   transactionsDB.find(
//     { $and: [{ ref_number: {$ne: ""}}, { status: 0  }]},    
//     function(err, docs) {
//       if (docs) res.send(docs);
//     }
//   );
// });



// app.get("/customer-orders", function(req, res) {
//   transactionsDB.find(
//     { $and: [{ customer: {$ne: "0"} }, { status: 0}, { ref_number: ""}]},
//     function(err, docs) {
//       if (docs) res.send(docs);
//     }
//   );
// });



// app.get("/by-date", function(req, res) {

//   let startDate = new Date(req.query.start);
//   let endDate = new Date(req.query.end);

//   if(req.query.user == 0 && req.query.till == 0) {
//       transactionsDB.find(
//         { $and: [{ date: { $gte: startDate.toJSON(), $lte: endDate.toJSON() }}, { status: parseInt(req.query.status) }] },
//         function(err, docs) {
//           if (docs) res.send(docs);
//         }
//       );
//   }

//   if(req.query.user != 0 && req.query.till == 0) {
//     transactionsDB.find(
//       { $and: [{ date: { $gte: startDate.toJSON(), $lte: endDate.toJSON() }}, { status: parseInt(req.query.status) }, { user_id: parseInt(req.query.user) }] },
//       function(err, docs) {
//         if (docs) res.send(docs);
//       }
//     );
//   }

//   if(req.query.user == 0 && req.query.till != 0) {
//     transactionsDB.find(
//       { $and: [{ date: { $gte: startDate.toJSON(), $lte: endDate.toJSON() }}, { status: parseInt(req.query.status) }, { till: parseInt(req.query.till) }] },
//       function(err, docs) {
//         if (docs) res.send(docs);
//       }
//     );
//   }

//   if(req.query.user != 0 && req.query.till != 0) {
//     transactionsDB.find(
//       { $and: [{ date: { $gte: startDate.toJSON(), $lte: endDate.toJSON() }}, { status: parseInt(req.query.status) }, { till: parseInt(req.query.till) }, { user_id: parseInt(req.query.user) }] },
//       function(err, docs) {
//         if (docs) res.send(docs);
//       }
//     );
//   }

// });



// app.post("/new", function(req, res) {
//   let newTransaction = req.body;
//   transactionsDB.insert(newTransaction, function(err, transaction) {    
//     if (err) res.status(500).send(err);
//     else {
//      res.sendStatus(200);

//      if(newTransaction.paid >= newTransaction.total){
//         Inventory.decrementInventory(newTransaction.items);
//      }
     
//     }
//   });
// });



// app.put("/new", function(req, res) {
//   let oderId = req.body._id;
//   transactionsDB.update( {
//       _id: oderId
//   }, req.body, {}, function (
//       err,
//       numReplaced,
//       order
//   ) {
//       if ( err ) res.status( 500 ).send( err );
//       else res.sendStatus( 200 );
//   } );
// });


// app.post( "/delete", function ( req, res ) {
//  let transaction = req.body;
//   transactionsDB.remove( {
//       _id: transaction.orderId
//   }, function ( err, numRemoved ) {
//       if ( err ) res.status( 500 ).send( err );
//       else res.sendStatus( 200 );
//   } );
// } );



// app.get("/:transactionId", function(req, res) {
//   transactionsDB.find({ _id: req.params.transactionId }, function(err, doc) {
//     if (doc) res.send(doc[0]);
//   });
// });
