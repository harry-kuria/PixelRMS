const express = require("express");
const bodyParser = require("body-parser");
const mysql = require("mysql");

const app = express();
app.use(bodyParser.json());

// MySQL Connection Configuration
const connection = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "H@rri50n",
  database: "POS_users"
});

// Connect to MySQL
connection.connect((err) => {
  if (err) {
    console.error('Error connecting to MySQL: ' + err.stack);
    return;
  }
  console.log('Connected to MySQL as id ' + connection.threadId);
});

// Routes
app.get("/", (req, res) => {
  res.send("Users API");
});

// Get user by ID
app.get("/user/:userId", (req, res) => {
  const userId = req.params.userId;
  if (!userId) {
    return res.status(500).send("ID field is required.");
  }

  connection.query("SELECT * FROM users WHERE id = ?", [userId], (err, results) => {
    if (err) {
      console.error("Error getting user:", err);
      return res.status(500).send(err.message);
    }
    res.send(results[0]);
  });
});

// Logout user by ID
app.get("/logout/:userId", (req, res) => {
  const userId = req.params.userId;
  if (!userId) {
    return res.status(500).send("ID field is required.");
  }

  connection.query(
    "UPDATE users SET status = ? WHERE id = ?",
    [`Logged Out_${new Date()}`, userId],
    (err, result) => {
      if (err) {
        console.error("Error updating user:", err);
        return res.status(500).send(err.message);
      }
      res.sendStatus(200);
    }
  );
});

// Login endpoint
app.post("/login", (req, res) => {
  const username = req.body.username;
  const password = req.body.password;

  connection.query(
    "SELECT * FROM users WHERE username = ? AND password = ?",
    [username, password],
    (err, results) => {
      if (err) {
        console.error("Error finding user:", err);
        return res.status(500).send(err.message);
      }
      if (results.length > 0) {
        const userId = results[0].id;
        connection.query(
          "UPDATE users SET status = ? WHERE id = ?",
          [`Logged In_${new Date()}`, userId],
          (err, result) => {
            if (err) {
              console.error("Error updating user status:", err);
              return res.status(500).send(err.message);
            }
            res.send(results[0]);
          }
        );
      } else {
        res.sendStatus(401); // Unauthorized
      }
    }
  );
});

app.post("/post", (req, res) => {
    const newUser = {
      username: req.body.username,
      password: req.body.password,
      fullname: req.body.fullname,
      perm_products: req.body.perm_products == "on" ? 1 : 0,
      perm_categories: req.body.perm_categories == "on" ? 1 : 0,
      perm_transactions: req.body.perm_transactions == "on" ? 1 : 0,
      perm_users: req.body.perm_users == "on" ? 1 : 0,
      perm_settings: req.body.perm_settings == "on" ? 1 : 0,
      status: ""
      
    };
  
    connection.query("INSERT INTO users SET ?", newUser, (err, result) => {
      if (err) {
        console.error("Error creating user:", err);
        return res.status(500).send(err.message);
      }
      res.send(newUser);
    });
  });

  // Update user details
app.put("/user/:userId", (req, res) => {
    const userId = req.params.userId;
    const updatedUser = {
        username: req.body.username,
        password: req.body.password,
        fullname: req.body.fullname,
        perm_products: req.body.perm_products == "on" ? 1 : 0,
        perm_categories: req.body.perm_categories == "on" ? 1 : 0,
        perm_transactions: req.body.perm_transactions == "on" ? 1 : 0,
        perm_users: req.body.perm_users == "on" ? 1 : 0,
        perm_settings: req.body.perm_settings == "on" ? 1 : 0
      // Add other properties as needed
    };
  
    connection.query(
      "UPDATE users SET ? WHERE id = ?",
      [updatedUser, userId],
      (err, result) => {
        if (err) {
          console.error("Error updating user:", err);
          return res.status(500).send(err.message);
        }
        res.send(updatedUser);
      }
    );
  });

  app.get("/all", (req, res) => {
    connection.query("SELECT * FROM users", (err, results) => {
      if (err) {
        console.error("Error getting users:", err);
        return res.status(500).send(err.message);
      }
      res.send(results);
    });
  });
  
  // Delete user by ID
  app.delete("/user/:userId", (req, res) => {
    const userId = req.params.userId;
    connection.query("DELETE FROM users WHERE id = ?", userId, (err, result) => {
      if (err) {
        console.error("Error deleting user:", err);
        return res.status(500).send(err.message);
      }
      res.sendStatus(200);
    });
  });
  
const port = process.env.PORT || 8001;
app.listen(port, () => {
  console.log(`Server is listening on port ${port}`);
});


// const app = require( "express")();
// const server = require( "http" ).Server( app );
// const bodyParser = require( "body-parser" );
// const Datastore = require( "nedb" );
// const btoa = require('btoa');
// app.use( bodyParser.json() );

// module.exports = app;

 
// let usersDB = new Datastore( {
//     filename: process.env.APPDATA+"/POS/server/databases/users.db",
//     autoload: true
// } );


// usersDB.ensureIndex({ fieldName: '_id', unique: true });


// app.get( "/", function ( req, res ) {
//     res.send( "Users API" );
// } );


  
// app.get( "/user/:userId", function ( req, res ) {
//     if ( !req.params.userId ) {
//         res.status( 500 ).send( "ID field is required." );
//     }
//     else{
//     usersDB.findOne( {
//         _id: parseInt(req.params.userId)
// }, function ( err, docs ) {
//         res.send( docs );
//     } );
//     }
// } );



// app.get( "/logout/:userId", function ( req, res ) {
//     if ( !req.params.userId ) {
//         res.status( 500 ).send( "ID field is required." );
//     }
//     else{ usersDB.update( {
//             _id: parseInt(req.params.userId)
//         }, {
//             $set: {
//                 status: 'Logged Out_'+ new Date()
//             }
//         }, {},
//     );

//     res.sendStatus( 200 );
 
//     }
// });



// app.post( "/login", function ( req, res ) {  
//     usersDB.findOne( {
//         username: req.body.username,
//         password: btoa(req.body.password)

// }, function ( err, docs ) {
//         if(docs) {
//             usersDB.update( {
//                 _id: docs._id
//             }, {
//                 $set: {
//                     status: 'Logged In_'+ new Date()
//                 }
//             }, {},
            
//         );
//         }
//         res.send( docs );
//     } );
    
// } );




// app.get( "/all", function ( req, res ) {
//     usersDB.find( {}, function ( err, docs ) {
//         res.send( docs );
//     } );
// } );



// app.delete( "/user/:userId", function ( req, res ) {
//     usersDB.remove( {
//         _id: parseInt(req.params.userId)
//     }, function ( err, numRemoved ) {
//         if ( err ) res.status( 500 ).send( err );
//         else res.sendStatus( 200 );
//     } );
// } );

 
// app.post( "/post" , function ( req, res ) {   
//     let User = { 
//             "username": req.body.username,
//             "password": btoa(req.body.password),
//             "fullname": req.body.fullname,
//             "perm_products": req.body.perm_products == "on" ? 1 : 0,
//             "perm_categories": req.body.perm_categories == "on" ? 1 : 0,
//             "perm_transactions": req.body.perm_transactions == "on" ? 1 : 0,
//             "perm_users": req.body.perm_users == "on" ? 1 : 0,
//             "perm_settings": req.body.perm_settings == "on" ? 1 : 0,
//             "status": ""
//           }

//     if(req.body.id == "") { 
//        User._id = Math.floor(Date.now() / 1000);
//        usersDB.insert( User, function ( err, user ) {
//             if ( err ) res.status( 500 ).send( req );
//             else res.send( user );
//         });
//     }
//     else { 
//         usersDB.update( {
//             _id: parseInt(req.body.id)
//                     }, {
//                         $set: {
//                             username: req.body.username,
//                             password: btoa(req.body.password),
//                             fullname: req.body.fullname,
//                             perm_products: req.body.perm_products == "on" ? 1 : 0,
//                             perm_categories: req.body.perm_categories == "on" ? 1 : 0,
//                             perm_transactions: req.body.perm_transactions == "on" ? 1 : 0,
//                             perm_users: req.body.perm_users == "on" ? 1 : 0,
//                             perm_settings: req.body.perm_settings == "on" ? 1 : 0
//                         }
//                     }, {}, function (
//             err,
//             numReplaced,
//             user
//         ) {
//             if ( err ) res.status( 500 ).send( err );
//             else res.sendStatus( 200 );
//         } );

//     }

// });


// app.get( "/check", function ( req, res ) {
//     usersDB.findOne( {
//         _id: 1
// }, function ( err, docs ) {
//         if(!docs) {
//             let User = { 
//                 "_id": 1,
//                 "username": "admin",
//                 "password": btoa("admin"),
//                 "fullname": "Administrator",
//                 "perm_products": 1,
//                 "perm_categories": 1,
//                 "perm_transactions": 1,
//                 "perm_users": 1,
//                 "perm_settings": 1,
//                 "status": ""
//               }
//             usersDB.insert( User, function ( err, user ) {                            
//             });
//         }
//     } );
// } );
 